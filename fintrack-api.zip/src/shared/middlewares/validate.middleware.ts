import { NextFunction, Request, Response } from "express";
import { AppError } from "./error.middleware";

export const validate = (schema: any, property: "body" | "params" | "query") => { 
  return (req: Request, _res: Response, next: NextFunction) => {
    const { error } = schema.validate(req[property]);
    if (error) {
      throw new AppError(error.details[0].message, 400);
    }
    next();
  };
}