import TransactionsRepository from "../repositories/transactions.repository";

export default class DeleteService {

  constructor(readonly transactionsRepository: TransactionsRepository) {}

  async execute(userId: string, role: string, transactionId: string) {
    const transaction = await this.transactionsRepository.findById(transactionId);
    if (!transaction || (transaction.userId !== userId && role !== "ADMIN") || transaction.deletedAt) {
      throw new Error("Transaction not found or you don't have permission to delete it");
    }
    return this.transactionsRepository.delete(transactionId);
  }
}