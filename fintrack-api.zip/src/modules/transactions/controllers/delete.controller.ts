import { Response } from "express";
import { AuthenticatedRequest } from "../../../shared/middlewares/auth.middleware";
import { prisma } from "../../../shared/database/prisma";
import TransactionsRepository from "../repositories/transactions.repository";
import DeleteService from "../services/delete.service";

export default async function DeleteController(req: AuthenticatedRequest, res: Response) {
  const transactionsRepository = new TransactionsRepository(prisma);
  const deleteService = new DeleteService(transactionsRepository);
  const deletedTransaction = await deleteService.execute(req.user!.id, req.user!.role, req.params['id'] as string);
  return res.ok(deletedTransaction);
}