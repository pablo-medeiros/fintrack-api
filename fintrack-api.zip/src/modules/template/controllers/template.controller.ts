import { Response } from "express";
import { AuthenticatedRequest } from "../../../shared/middlewares/auth.middleware";
import TemplateDTO from "../dtos/template.dto";
import TemplateRepository from "../repositories/template.repository";
import TemplateService from "../services/template.service";
import { prisma } from "../../../shared/database/prisma";

export default async function TemplateController(req: AuthenticatedRequest, res: Response) {
  const templateDTO = req.body as TemplateDTO;
  const templateRepository = new TemplateRepository(prisma);
  const templateService = new TemplateService(templateRepository);
  const createdTemplate = await templateService.execute(templateDTO);
  return res.created(createdTemplate);
}