import Joi from "joi";

export const TemplateSchema = Joi.object({
});
