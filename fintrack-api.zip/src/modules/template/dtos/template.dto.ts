
export default interface TemplateDTO {
}