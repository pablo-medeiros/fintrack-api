import { Router } from "express";

export const TemplateRouter = Router();
  