import { $Enums, Prisma, PrismaClient } from "@prisma/client";

export default class TemplateRepository {

  constructor(readonly prisma: PrismaClient) {}

  
}