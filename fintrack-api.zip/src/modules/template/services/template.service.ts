import TemplateDTO from "../dtos/template.dto";
import TemplateRepository from "../repositories/template.repository";

export default class TemplateService {

  constructor(readonly templateRepository: TemplateRepository) {}

  async execute(templateDTO: TemplateDTO) {
  }
}